#ifndef _LIGHTSENSOR__
#define _LIGHTSENSOR__

void LightSensor(void);
uint8_t LightSensor_Get(void);





#endif
