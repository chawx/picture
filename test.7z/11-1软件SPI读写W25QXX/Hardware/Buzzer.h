#ifndef _Buzzer__H
#define _Buzzer__H

void Buzzer_Init(void);
void Buzzer_ON(void);
void Buzzer_Off(void);
void Buzzer_Turn(void);

#endif 
