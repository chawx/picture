#ifndef __LED_H
#define __LED_H

void Led_init(void);
void Led1_ON(void);
void Led2_ON(void);
void Led1_Off(void);
void Led2_Off(void);
void Led1_Turn(void);
void Led2_Turn(void);

/*GPIO��Ҫ����6���⺯��                                            */
/*
uint8_t GPIO_ReadInputDataBit(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin);
uint16_t GPIO_ReadInputData(GPIO_TypeDef* GPIOx);
uint8_t GPIO_ReadOutputDataBit(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin);
uint16_t GPIO_ReadOutputData(GPIO_TypeDef* GPIOx);
void GPIO_SetBits(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin);
void GPIO_ResetBits(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin);
*/
/**/


#endif
