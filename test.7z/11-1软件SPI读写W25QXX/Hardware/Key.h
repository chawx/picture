#ifndef _KEY__H
#define _KEY__H

void Key_Init(void);
uint8_t Key_GetNum(void);


#endif 
