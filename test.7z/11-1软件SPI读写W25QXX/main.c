#include "Device/Include/stm32f10x.h"   // Device header

int main(void)
{
        
        while(1);
        {

        }

}
