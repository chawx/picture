#include "stm32f10x.h"
#include "Delay.h"
#include "Led.h"
#include "Key.h"
#include "Buzzer.h"

uint8_t KeyNum;//全局变量

int main(void)
{
        Led_init();
        Key_Init();
        Buzzer_Init();

        while(1)
        {
                KeyNum = Key_GetNum();
                if(KeyNum == 1)
                {
                        Led1_Turn();
                        Buzzer_ON();
                }
                if(KeyNum == 2)
                {
                        Led2_Turn();
                        Buzzer_Off();
                }
        }
}
