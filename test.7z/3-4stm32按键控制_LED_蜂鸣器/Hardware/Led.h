#ifndef __LED_H
#define __LED_H

void Led_init(void);
void Led1_ON(void);
void Led2_ON(void);
void Led1_Off(void);
void Led2_Off(void);
void Led1_Turn(void);
void Led2_Turn(void);


#endif
