#include "stm32f10x.h"   // Device header
#include "Delay.h"


void Led_init(void)
{
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
    GPIO_InitTypeDef GPIO_InitStructure;

    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_0 | GPIO_Pin_1;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA,&GPIO_InitStructure);

    GPIO_SetBits(GPIOA,GPIO_Pin_0 | GPIO_Pin_1);
}    

void Led1_ON(void)
{
    GPIO_ResetBits(GPIOA, GPIO_Pin_0);
}

void Led2_ON(void)
{
    GPIO_ResetBits(GPIOA, GPIO_Pin_1);
}

void Led1_Off(void)
{
    GPIO_SetBits(GPIOA, GPIO_Pin_0);
}

void Led2_Off(void)
{
    GPIO_SetBits(GPIOA, GPIO_Pin_1);
}

void Led1_Turn(void)
{
    if(GPIO_ReadOutputDataBit(GPIOA, GPIO_Pin_0) == 0){
        GPIO_SetBits(GPIOA, GPIO_Pin_0);
    }
    else{
        GPIO_ResetBits(GPIOA, GPIO_Pin_0);
    }
}
/* GPIO_ReadOutputDataBit(GPIOA, GPIO_Pin_1) 默认是高电平，也就按下键盘先执行else后面函数 */
void Led2_Turn(void)
{
    if(GPIO_ReadOutputDataBit(GPIOA, GPIO_Pin_1) == 0){
        GPIO_SetBits(GPIOA, GPIO_Pin_1);
    }
    else{
        GPIO_ResetBits(GPIOA, GPIO_Pin_1);
    }

}
