#include "stm32f10x.h"   // Device header
#include "Led.h"

/**********************AFIO配置函数用法********************/
/* EXTI和NVIC的外设时钟一直打开,不用配置                   */
/* NVIC是内核外设，不用进行配置                            */
/* AFIO的库函数是跟Gpio在头一个.h文件                      */
/* void GPIO_AFIODeInit(void); 复位AFIO 将AFIO配置全部清除 */
/* void GPIO_PinLockConfig(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin); 锁定引脚，防止意外更改*/
/* void GPIO_EventOutputConfig(uint8_t GPIO_PortSource, uint8_t GPIO_PinSource);
   void GPIO_EventOutputCmd(FunctionalState NewState); 这两个配置AFIO的事情输出功能*/
/* void GPIO_PinRemapConfig(uint32_t GPIO_Remap, FunctionalState NewState); 功能：进行引脚重映射
void GPIO_EXTILineConfig(uint8_t GPIO_PortSource, uint8_t GPIO_PinSource); 
功能:外部中断函数，可以配置AFIO的数据选择器，选择想要的中断引脚*/
/* void GPIO_ETH_MediaInterfaceConfig(uint32_t GPIO_ETH_MediaInterface); 跟以太网外设有关*/
/*********************************************************/

/********************EXTI配置函数用法***********************/
/* void EXTI_DeInit(void);清除EXTI配置 */
/* void EXTI_Init(EXTI_InitTypeDef* EXTI_InitStruct);配置EXTI的外设 */
/* void EXTI_StructInit(EXTI_InitTypeDef* EXTI_InitStruct); 参数传递的结构体变量赋值 */
/* void EXTI_GenerateSWInterrupt(uint32_t EXTI_Line);软件触发中断 */

/*******如果你想在主程序里查看和清楚标志位就用下面2个函数*******/

/* FlagStatus EXTI_GetFlagStatus(uint32_t EXTI_Line); 是否有中断标志位*/
/* void EXTI_ClearFlag(uint32_t EXTI_Line);进行清楚标志位 */

/*******如果你想在中断函数里查看和清楚标志位，就用下面2个函数***/

/* ITStatus EXTI_GetITStatus(uint32_t EXTI_Line);获取中断标志位是否被值1了 */
/* void EXTI_ClearITPendingBit(uint32_t EXTI_Line);清楚中断标志位 */

/**********************************************************/

/**********************************************************/
/* void NVIC_PriorityGroupConfig(uint32_t NVIC_PriorityGroup); 中断分组*/
/* void NVIC_Init(NVIC_InitTypeDef* NVIC_InitStruct); 初始化NVIC*/
/* void NVIC_SetVectorTable(uint32_t NVIC_VectTab, uint32_t Offset); 设置中断向量比表*/ 
/* void NVIC_SystemLPConfig(uint8_t LowPowerMode, FunctionalState NewState); 系统低功耗配置*/
/* void SysTick_CLKSourceConfig(uint32_t SysTick_CLKSource); */

/**********************************************************/

uint16_t CountSensor_Count = 0;

void CountSensor_Init(void)
{
    /*************************AFIO配置*************************************/
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);

    GPIO_InitTypeDef GPIO_initStructure;
    GPIO_initStructure.GPIO_Mode  = GPIO_Mode_IPU;
    GPIO_initStructure.GPIO_Pin   = GPIO_Pin_14;
    GPIO_initStructure.GPIO_Speed = GPIO_Speed_50MHz;

    GPIO_Init(GPIOB,&GPIO_initStructure);

    GPIO_EXTILineConfig(GPIO_PortSourceGPIOB,GPIO_PinSource14);/* AFIO配置 */
    
    /*************************EXTI配置*************************************/

    EXTI_InitTypeDef EXTI_InitStructure;
    EXTI_InitStructure.EXTI_Line    = EXTI_Line14;/*指定我们我们要配置的中断线*/
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_InitStructure.EXTI_Mode    = EXTI_Mode_Interrupt;/*  EXTI_Mode_Interrupt = 0x00, 中断模式
                                                              EXTI_Mode_Event = 0x04 事件模式 */
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;/* 下降沿触发 */
    EXTI_Init(&EXTI_InitStructure);

    /*************************NVIC配置*************************************/
    /*********************NVIC是内核外设在misc.h文件里**********************/

    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    NVIC_InitTypeDef NVIC_InitStructure;
    NVIC_InitStructure.NVIC_IRQChannel                     = EXTI15_10_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelCmd                  = ENABLE;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority   = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority          = 1;
    NVIC_Init(&NVIC_InitStructure);

}

uint16_t CountSensor_Get(void)
{
    return CountSensor_Count;
}

void EXTI15_10_IRQHandler(void)
{
    if(EXTI_GetITStatus(EXTI_Line14) == SET)
    {
        if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_14) == 0)
        {
            CountSensor_Count ++;
           
        }
         Led1_ON();
    }
    EXTI_ClearITPendingBit(EXTI_Line14);
}

