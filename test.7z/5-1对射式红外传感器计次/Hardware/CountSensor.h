#ifndef __COUNTSENSOR__
#define __COUNTSENSOR__

void CountSensor_Init(void);
uint16_t CountSensor_Get(void);

#endif
