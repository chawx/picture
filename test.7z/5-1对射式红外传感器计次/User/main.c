#include "stm32f10x.h"
#include "Delay.h"
#include "Led.h"
#include "Key.h"
#include "Buzzer.h"
#include "LightSensor.h"
#include "OLED.h"
#include "CountSensor.h"

uint8_t KeyNum;//全局变量
uint8_t LightSensor_Gets;

int main(void)
{
    OLED_Init();
    CountSensor_Init();

    OLED_ShowString(1,3,"Hellod world");
    OLED_ShowString(2,1,"Count:");

    while(1)
    {
        OLED_ShowNum(2,7,CountSensor_Get(),5);
    }
}
