#include "stm32f10x.h"
#include "Delay.h"
#include "Led.h"
#include "Key.h"
#include "Buzzer.h"
#include "LightSensor.h"
#include "OLED.h"
#include "Serial.h"
#include <stdio.h>


uint8_t KeyNum;//全局变量
uint8_t LightSensor_Gets;

int main(void)
{
    OLED_Init();
    Serial_Init();
//    Serial_SendByte(0x41);
//    uint8_t MyArray[] = {0x43 ,0x44 ,0x45 ,0x46};
//    Serial_SendArray(MyArray,4);
//    Serail_SendString("zhzhzh\r\n");
    
//    printf("NUM=%d\n",666);
//以下是多个串口用的串口方式
//    char string[100];
//    sprintf(string,"NUM=%d\n",123);
//    Serail_SendString(string);
    Serial_Printf("对的，对的\r\n");

    while(1)
    {

    }
}
